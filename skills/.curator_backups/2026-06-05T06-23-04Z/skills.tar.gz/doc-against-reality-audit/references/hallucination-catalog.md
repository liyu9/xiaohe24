# Hallucination Catalog — Verified Wrong vs. Correct

A running list of specific claims that have appeared in user-supplied setup guides and been verified **wrong** against the live Hermes 0.15.x system. Use this to short-circuit audits: if the doc says X, check the catalog first.

## Path / directory

| Doc claim | Reality |
|---|---|
| `~/.hermes/personas/soul.md` | `~/.hermes/SOUL.md` (single file, not in `personas/`) |
| `~/.hermes/personas/product-manager.md` | Doesn't exist; the system has 14 built-in personalities in `agent.personalities` (`helpful`/`concise`/`technical`/`creative`/`teacher`/`kawaii`/`catgirl`/`pirate`/`shakespeare`/`surfer`/`noir`/`uwu`/`philosopher`/`hype`); you select via `display.personality` |
| `~/.hermes/teams/` | Doesn't exist; no multi-agent team config |
| `~/.hermes/knowledge/` | Doesn't exist; knowledge lives in `~/.hermes/skills/<name>/SKILL.md` |

## Config keys (yaml)

| Doc claim | Reality |
|---|---|
| `persona: default: "soul"` | No such field; `display.personality: <one of 14 enum values>` |
| `auto_improve: true` | Doesn't exist; the closest real fields are `skills.guard_agent_created`, `curator.enabled`, `agent.disabled_toolsets` |
| `lazy_load: true` / `max_loaded_skills: 8` | Doesn't exist; skills are loaded by trigger matching, not lazy thresholds |
| `memory.embedding_model: bge-micro-zh` | Doesn't exist; Hermes memory is **FTS5 full-text over session DB**, not a vector store. `memory.memory_enabled` / `memory.user_profile_enabled` are the real switches |
| `memory.long_term` / `memory.episodic` / `memory.semantic` | None of these exist |
| `compression.enabled: false` | Real, but default is `true` (not "off as doc suggests for safety") |
| `tool_call_timeout: 30` | Real field is `agent.gateway_timeout` (default 1800s) — affects everything, not just tool calls |
| `parallel_tool_calls: false` | Doesn't exist; the LLM controls parallelism, not the config |
| `smart_approval: true` | Doesn't exist; the real switch is `approvals.mode` (`manual`/`smart`/`off`) |
| `auto_retry: 1` | Real field is `agent.api_max_retries` (default 3) |
| `execution.max_turns: 5` | Real field is `agent.max_turns` (default 60, NOT 5); `goals.max_turns: 20` is the goal-task limit, different field |
| `api_key` under `security:` | Real: `api_key` lives under `model:` and `providers.<name>`, not `security:`. The security section has `tirith_*`, `allow_private_urls`, `redact_secrets`, `website_blocklist` |
| `allowed_ips: [...]` under `security:` | Doesn't exist; IP filtering is a platform feature, not a config field |
| `provider: "anthropic"` | Real provider id format is `custom:<name>` (e.g. `custom:minimax_coding`) |

## CLI commands

| Doc claim | Reality |
|---|---|
| `hermes profile create product-manager` | Doesn't exist; `hermes profile` exists but has no `create` subcommand in 0.15.x |
| `hermes config validate` | Doesn't exist; use `hermes config check` |
| `hermes doctor` | **Does** exist (verify with `hermes --help` first; some older guides are wrong) |
| `hermes memory import <file>` | Doesn't exist |
| `hermes memory list` | Doesn't exist as CLI; the `memory` tool is a function call, not a CLI subcommand |
| `hermes skills publish` | **Does** exist as of 0.15.x; verify before claiming wrong |

## Network / endpoints

| Doc claim | Reality |
|---|---|
| "Use `mirror.ghproxy.com` for GitHub proxy" | Mirror itself is **blocked from Tencent Cloud egress** (HTTP 000) as of 2026-06. Use `gh-proxy.com` or `gh.idayer.com` for GET; **neither proxies push**; for push, switch to SSH |
| "Configure proxy in `~/.hermes/config.yaml` under `proxy:`" | No `proxy:` section in config; proxy is set via env vars (`HTTPS_PROXY`, `HTTP_PROXY`) or by `terminal.backend: docker` with `docker_extra_args` |
| "Add cloud provider integration in config" | No cloud-provider integration in Hermes core; you'd need a plugin |

## Behavioral claims

| Doc claim | Reality |
|---|---|
| "切换人格用 `/personality X` 命令" | Real slash command is `/personality <name>` (single arg, one of the 14 enum) — works, but only switches between the built-ins, not user-defined yaml |
| "Hermes will auto-create skills based on usage" | `skills.guard_agent_created` defaults `false`; auto-creation needs the agent to *propose* a skill, which only happens after a complex task completes |
| "Memory is shared across all Hermes profiles" | **No.** Each profile has its own `~/.hermes/profiles/<name>/` and own memory. Sharing requires explicit export/import |
| "Set `max_turns: 5` to save tokens" | At 5, almost any multi-step task (search → read → fix → verify) gets cut off. Use 20-40 for typical work, 60+ for code refactors |

## How to extend this catalog

When a new doc audit turns up a wrong claim that isn't here:

1. Add a row in the right section with `Doc claim` and `Reality`
2. Include the Hermes version you verified against (e.g. "verified Hermes 0.15.1")
3. If the doc was a Xmind/Markdown/PDF, keep the file path in a comment so you can re-check on version bumps

The catalog only stays useful if it tracks the **specific** (doc string → real config) pairs, not the general "docs lie" principle.

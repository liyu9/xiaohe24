#!/bin/bash
# Verify a Feishu (Lark) app credential configured in ~/.hermes/.env.
# Usage: bash scripts/feishu-app-secret-verify.sh
# Exit 0 if the credential produces a valid tenant_access_token.
# Exit 1 if env not loaded, values missing, or API returned an error.

set -e

ENV_FILE="${HOME}/.hermes/.env"

# 1. .env exists and is mode 600
if [ ! -f "$ENV_FILE" ]; then
  echo "FAIL: $ENV_FILE not found" >&2
  exit 1
fi
PERMS=$(stat -c '%a' "$ENV_FILE" 2>/dev/null || stat -f '%Lp' "$ENV_FILE" 2>/dev/null)
if [ "$PERMS" != "600" ]; then
  echo "WARN: $ENV_FILE has mode $PERMS, expected 600 — secrets are world-readable" >&2
  echo "      fix: chmod 600 $ENV_FILE" >&2
fi

# 2. Load env
set -a
# shellcheck disable=SC1090
. "$ENV_FILE"
set +a

# 3. Both required vars must be non-empty
if [ -z "${FEISHU_APP_ID:-}" ] || [ -z "${FEISHU_APP_SECRET:-}" ]; then
  echo "FAIL: FEISHU_APP_ID and/or FEISHU_APP_SECRET empty in $ENV_FILE" >&2
  exit 1
fi

# 4. App ID format check (cli_xxxxxxxxxxxx)
if ! [[ "$FEISHU_APP_ID" =~ ^cli_[A-Za-z0-9]{16,}$ ]]; then
  echo "WARN: FEISHU_APP_ID '$FEISHU_APP_ID' does not match expected 'cli_*' format" >&2
fi

# 5. App Secret length check (32 chars)
SECRET_LEN=${#FEISHU_APP_SECRET}
if [ "$SECRET_LEN" != "32" ]; then
  echo "WARN: FEISHU_APP_SECRET length is $SECRET_LEN, expected 32" >&2
fi

# 6. Hit the actual API
echo "Calling auth/v3/tenant_access_token/internal ..."
RESPONSE=$(curl -s -X POST \
  "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d "{\"app_id\":\"$FEISHU_APP_ID\",\"app_secret\":\"$FEISHU_APP_SECRET\"}")

CODE=$(echo "$RESPONSE" | jq -r '.code // empty')
TOKEN=$(echo "$RESPONSE" | jq -r '.tenant_access_token // empty')

if [ "$CODE" != "0" ] || [ -z "$TOKEN" ]; then
  echo "FAIL: API returned non-success" >&2
  echo "  response: $RESPONSE" >&2
  exit 1
fi

echo "OK: tenant_access_token = $TOKEN (valid for 2h)"
echo "App ID:  $FEISHU_APP_ID"
echo "Secret:  ${FEISHU_APP_SECRET:0:4}...${FEISHU_APP_SECRET: -4} (length $SECRET_LEN)"
echo "Perms:   $PERMS"

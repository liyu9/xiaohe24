---
name: finance-data
description: Fetch real-time and historical stock/equity quotes from free public endpoints without API keys. Covers A股 (沪深北交所 via tencent qt.gtimg.cn, sina), HK stocks (Tencent Finance qt.gtimg.cn, AAStocks), and US stocks (Stooq, Yahoo unofficial). Use when the user asks for stock price, market quote, 实时行情, 分时, K线, 涨跌, 成交额, or any "查一下 X 的股价" / "X 行情" / "X quote" request.
---

# Finance Data (free public endpoints)

Real-time quotes without API keys. The endpoints are public, rate-limited per-IP, and return GBK-encoded Chinese on Chinese sources — decode or pipe to `iconv`/`python3` for clean output.

## Endpoints

### A股 + 港股 (Tencent Finance) — primary

`https://qt.gtimg.cn/q=<market><code>` returns a single-line GBK string in the format
`v_<key>="~<name>~<code>~<price>~<prev_close>~<open>~<volume>~...~<change>~<pct>~..."`.

| Market | Prefix | Example          |
|--------|--------|------------------|
| 上证    | `sh`   | `sh600519`        |
| 深证    | `sz`   | `sz000001`        |
| 北证    | `bj`   | `bj830799`        |
| 港股    | `hk`   | `hk00700` (腾讯)  |

Quick quote (one-liner):
```bash
curl -sL "https://qt.gtimg.cn/q=hk00700" -H "User-Agent: Mozilla/5.0" \
  | iconv -f gbk -t utf-8
```

For multiple symbols, separate with commas:
```bash
curl -sL "https://qt.gtimg.cn/q=sh600519,sz000001,hk00700" -H "User-Agent: Mozilla/5.0" \
  | iconv -f gbk -t utf-8
```

### A股 realtime snapshot (Sina) — fallback
`https://hq.sinajs.cn/list=sh600519` — requires `Referer: https://finance.sina.com.cn` header. Returns a similar single-line string.

### A股 K线 / 历史K线 (Sina)
`https://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=sh600519&scale=240&ma=no&datalen=1023`
- `scale`: `240` = 日K, `60` = 小时, `30` = 30分钟, `15` = 15分钟, `5` = 5分钟, `1` = 1分钟
- Returns JSON array of `[day, open, high, low, close, volume]`.

### 美股 (Stooq) — primary
`https://stooq.com/q/l/?s=aapl.us&f=sd2t2ohlcv&h&e=csv`
- Append `.us` for US, `.uk` for LSE, etc.
- Returns CSV: `Symbol,Date,Time,Open,High,Low,Close,Volume`.

### 美股 (Yahoo unofficial) — flaky
`https://query1.finance.yahoo.com/v8/finance/chart/AAPL?interval=1d&range=1d`
- Often blocked or rate-limited. Try Stooq first.

## Parsing the Tencent string

Field positions for `qt.gtimg.cn` (delimiter `~`):
1. 名称 (name)
2. 代码 (code)
3. 当前价 (current price)
4. 昨收 (prev close)
5. 今开 (open)
6. 成交量 (lots for A股, shares for HK)
7. … (intraday buy/sell volumes)
8. … (intraday prices)
9. 涨跌额 (change)
10. 涨跌幅% (pct change)
11. 最高 (high)
12. 最低 (low)
13. … price/volume ladder
14. 成交额 (turnover, 元/HKD)
15. 52w high, 52w low, …

The full schema varies by market. Parse defensively (split on `~`, skip empty fields) rather than hard-coding positions. For full field reference per market, see `references/tencent-qt-schema.md` if you generate it; otherwise rely on the standard `~`-split.

## Pitfalls

- **GBK encoding on Chinese sources.** The raw bytes are GBK. A naked `curl` to stdout shows garbled CJK in the terminal but the data is correct. Pipe through `iconv -f gbk -t utf-8` for human-readable output, or `iconv -f gbk -t utf-8 // IGNORE` if some bytes are corrupt.
- **Use `iconv`, not `python3 -c` round-trips.** The fastest clean read of a Tencent or Sina quote is `curl -sL 'https://qt.gtimg.cn/q=hk00700' -H 'User-Agent: Mozilla/5.0' | iconv -f gbk -t utf-8`. Trying to decode via Python (`data.encode('latin-1').decode('gbk')`) works but is 10× slower and breaks if any byte is invalid. `iconv` is on every Linux box.
- **When parsing the raw string in scripts, don't double-decode.** If you do `curl ... | iconv -f gbk -t utf-8 | python3 -c "..."` and the Python script then tries `.encode('gbk').decode('utf-8')`, you've already corrupted the bytes. Pick one: either pipe through `iconv` and treat output as UTF-8 throughout, OR keep raw GBK and decode once in Python.
- **Tencent endpoint is HTTP, but use HTTPS** (`https://qt.gtimg.cn`). It works either way; HTTPS avoids MITM on untrusted networks.
- **Yahoo Finance is often blocked** from cloud IPs / data center egress. Don't rely on it; default to Tencent or Stooq.
- **No API key, but rate-limited.** Tens of requests/sec is fine; hundreds will get throttled. For bulk, batch into one request (comma-separated symbols) instead of looping.
- **Trading-hours caveat.** Quotes return the *last* price. Outside market hours, that's the previous close — say so explicitly when reporting to the user.
- **HK `volume` field is in shares, A股 `volume` is in 手 (lots = 100 shares).** Turnover (成交额) is always in the local currency.
- **Sina requires `Referer`.** Without `Referer: https://finance.sina.com.cn`, requests return 403.
- **52-week high/low may be `0.000` for newly-listed or suspended stocks.** Don't present zeros as real data.

## When to defer to a skill

- For A股 *analysis* (分时量能、主力资金、持仓盈亏) use the `a-stock-analysis` skill (installed via skillhub).
- For HK/US analysis beyond a quote, no installed skill covers it; do the analysis inline with the data above.
